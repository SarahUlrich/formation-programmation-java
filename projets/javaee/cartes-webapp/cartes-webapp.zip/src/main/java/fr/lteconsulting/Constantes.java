package fr.lteconsulting;

public interface Constantes
{
	public static final int NB_MAX_CARTES_PAR_MAIN = 10;
}
